# 🪟 Windows Quick Fix Guide

Your issue: **setup.sh doesn't work on Windows** (Git Bash/MINGW64 has issues with sed/line endings)

## ✅ Solution: Use Python Setup Instead

### Step 1: Run Python Setup

```bash
python setup.py
# or
python3 setup.py
```

This cross-platform script will:
- ✅ Create .env file
- ✅ Prompt for your token
- ✅ Save it correctly (no weird characters)
- ✅ Install dependencies
- ✅ Offer to start the bot

### Step 2: Enter Your Token

When prompted, paste your token from @BotFather:
```
8595362018:AAFVpQkElbjKa1vswdaeFwj7_NzG9ldsE-0
```

### Step 3: Test It

```bash
python test_token.py
```

If you see "✅ SUCCESS!", you're good to go!

### Step 4: Start the Bot

```bash
python bot.py
```

---

## 🔧 Manual Fix (If setup.py fails)

### Method 1: Edit .env in Notepad

1. **Delete the broken .env file:**
   ```bash
   rm .env
   ```

2. **Copy template:**
   ```bash
   cp .env.example .env
   ```

3. **Open in Notepad (NOT Notepad++):**
   ```bash
   notepad .env
   ```

4. **Find this line:**
   ```
   BOT_TOKEN=PUT_TOKEN_HERE
   ```

5. **Replace with your token:**
   ```
   BOT_TOKEN=8595362018:AAFVpQkElbjKa1vswdaeFwj7_NzG9ldsE-0
   ```

6. **Save and close**

7. **Test:**
   ```bash
   python test_token.py
   python bot.py
   ```

### Method 2: Use PowerShell (Recommended)

1. **Open PowerShell** (not Git Bash)

2. **Navigate to folder:**
   ```powershell
   cd C:\Users\flashback\Desktop\mikrobot_extended
   ```

3. **Run Python setup:**
   ```powershell
   python setup.py
   ```

4. **Enter token when prompted**

5. **Start bot:**
   ```powershell
   python bot.py
   ```

---

## ⚠️ Common Windows Issues

### Issue 1: Weird Characters in .env

**Symptom:**
```
.env: line 10: $'2~\026\026\026\0268595362018...
```

**Cause:** Git Bash's sed command adds escape characters

**Fix:**
```bash
# Delete broken .env
rm .env

# Use Python setup instead
python setup.py
```

### Issue 2: "Command not found: python"

**Fix:**
```bash
# Try python3
python3 setup.py

# Or use py launcher (Windows)
py setup.py
```

### Issue 3: Line Ending Issues (CRLF vs LF)

**Symptom:** Errors about line endings or `\r`

**Fix:** Use Python setup.py which handles this automatically

Or manually convert:
```bash
# Install dos2unix in Git Bash
dos2unix .env

# Then test
python test_token.py
```

---

## 🎯 Quick Recovery Steps

If everything is broken:

```bash
# 1. Start fresh
rm .env

# 2. Use Python setup (works on Windows)
python setup.py

# 3. When prompted, paste your token:
#    8595362018:AAFVpQkElbjKa1vswdaeFwj7_NzG9ldsE-0

# 4. Test
python test_token.py

# 5. Run
python bot.py
```

---

## ✅ Success Check

When it works, you'll see:

```
2026-02-18 11:21:45 [MikroBot] INFO: Starting MikroBot…
2026-02-18 11:21:45 [Monitor] INFO: Monitor started
2026-02-18 11:21:45 [Watchdog] INFO: Watchdog started
2026-02-18 11:21:45 [MikroBot] INFO: Bot is running. Press Ctrl+C to stop.
2026-02-18 11:21:45 [aiogram.dispatcher] INFO: Start polling

[Bot stays running - no immediate error]
```

**No "Token is invalid!" error!**

---

## 🪟 Windows-Specific Recommendations

1. **Use PowerShell instead of Git Bash** for running Python scripts
2. **Use `python setup.py`** instead of `./setup.sh`
3. **Edit .env with Notepad** (plain Notepad, not Notepad++ or VSCode)
4. **Use forward slashes** in paths even on Windows (Python handles them)

---

## 📝 Manual .env File (Failsafe)

If all else fails, create `.env` file manually:

1. Open Notepad
2. Paste this (replace with YOUR token):

```env
# MikroBot Configuration
BOT_TOKEN=8595362018:AAFVpQkElbjKa1vswdaeFwj7_NzG9ldsE-0
OWNER_ID=
LOG_LEVEL=INFO
STANDALONE=
MIKROTIK_HOST=172.17.0.1
MIKROTIK_USER=admin
MIKROTIK_PASS=
MIKROTIK_PORT=8728
```

3. Save as `.env` (with the dot) in `mikrobot_extended` folder
4. **File → Save As**
5. **Save as type:** All Files (*.*)
6. **File name:** `.env` (include the dot!)
7. Click Save

8. Test:
```bash
python test_token.py
python bot.py
```

---

**TL;DR for Windows: Don't use setup.sh, use `python setup.py` instead** ✨
