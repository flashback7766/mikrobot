# ⚠️ Your Token is Invalid or Revoked

## The Problem

You entered a token, but Telegram says "Unauthorized". This means:
- ❌ The token was revoked by @BotFather
- ❌ The token is incorrect
- ❌ The bot was deleted

## Quick Fix (3 Steps)

### Step 1: Get a Valid Token

Open Telegram and message [@BotFather](https://t.me/BotFather)

**Option A: If you already have a bot**
```
Send to @BotFather:
/mybots

→ Select your bot
→ API Token
→ Copy the token
```

If it says "Revoked" or shows "Regenerate", click that and copy the new token.

**Option B: Create a new bot**
```
Send to @BotFather:
/newbot

→ Enter bot name: My MikroTik Bot
→ Enter username: my_mikrotik_bot (must end in 'bot')
→ Copy the token (looks like: 123456789:ABCdefGHI...)
```

### Step 2: Update .env File

```bash
cd mikrobot_extended
nano .env
```

Change this line:
```env
BOT_TOKEN=8559618124:AAG2fuhwCwUCUNxS-jflzdi0wez4aj43l3s
```

To your new token:
```env
BOT_TOKEN=YOUR_NEW_TOKEN_HERE
```

**Important:**
- ✅ No spaces before or after the `=`
- ✅ No quotes around the token
- ✅ No extra characters

### Step 3: Test the Token

Before running the full bot, test if the token works:

```bash
python3 test_token.py
```

If you see "✅ SUCCESS!", your token is valid. Then:

```bash
python3 bot.py
```

---

## Diagnostic Tools

### Check Your Configuration
```bash
python3 diagnose.py
```

This will:
- ✅ Check if .env exists
- ✅ Verify token format
- ✅ Test if config loads correctly

### Test Token Validity
```bash
python3 test_token.py
```

This will:
- ✅ Actually connect to Telegram
- ✅ Show your bot details if valid
- ✅ Show error if invalid

---

## Common Mistakes

### ❌ Wrong: Extra spaces
```env
BOT_TOKEN = 123456789:ABCdefGHI
BOT_TOKEN=123456789:ABCdefGHI 
```

### ✅ Correct: No spaces
```env
BOT_TOKEN=123456789:ABCdefGHI
```

### ❌ Wrong: Quotes
```env
BOT_TOKEN="123456789:ABCdefGHI"
BOT_TOKEN='123456789:ABCdefGHI'
```

### ✅ Correct: No quotes
```env
BOT_TOKEN=123456789:ABCdefGHI
```

### ❌ Wrong: Still using placeholder
```env
BOT_TOKEN=PUT_TOKEN_HERE
```

### ✅ Correct: Real token
```env
BOT_TOKEN=123456789:ABCdefGHI
```

---

## Still Not Working?

### 1. Verify the token in .env matches BotFather

```bash
# Show your current token (masked)
grep BOT_TOKEN .env
```

Compare with what @BotFather shows.

### 2. Try exporting directly (bypass .env)

```bash
export BOT_TOKEN="your_token_here"
python3 bot.py
```

If this works, your .env file has a problem.

### 3. Check .env location

The .env file must be in the same directory as bot.py:

```bash
ls -la
# You should see both:
# -rw-r--r-- 1 user user  2645 bot.py
# -rw-r--r-- 1 user user   XXX .env
```

If .env is missing:
```bash
cp .env.example .env
nano .env  # Add your token
```

---

## What Success Looks Like

When your token is valid and bot.py runs:

```
2026-02-18 09:50:02 [MikroBot] INFO: Starting MikroBot…
2026-02-18 09:50:02 [Monitor] INFO: Monitor started
2026-02-18 09:50:02 [Watchdog] INFO: Watchdog started
2026-02-18 09:50:02 [MikroBot] INFO: Bot is running. Press Ctrl+C to stop.
2026-02-18 09:50:02 [aiogram.dispatcher] INFO: Start polling

[NO ERROR AFTER THIS - bot keeps running]
```

**No "Unauthorized" error!**  
**No "Polling stopped" immediately!**

Then open Telegram and message your bot.

---

## Need a Fresh Start?

```bash
# Delete old bot in @BotFather
Send to @BotFather: /mybots → Delete Bot

# Create new bot
Send to @BotFather: /newbot
# Follow prompts, copy token

# Update .env
nano .env
# Paste new token

# Test
python3 test_token.py

# Run
python3 bot.py
```

---

**The token you entered is definitely invalid. Get a new one from @BotFather.** 🔑
