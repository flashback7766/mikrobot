# ⚡ QUICK FIX — Unauthorized Error

## Your Error

```
aiogram.exceptions.TelegramUnauthorizedError: Telegram server says - Unauthorized
```

## The Problem

Your bot token is not configured. The bot is trying to connect with the placeholder value `"PUT_TOKEN_HERE"`.

## The Solution (Choose One)

### Option 1: Environment Variable (Quick)

```bash
export BOT_TOKEN="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
python3 bot.py
```

Replace `123456789:ABCdefGHIjklMNOpqrsTUVwxyz` with your actual token from [@BotFather](https://t.me/BotFather).

### Option 2: .env File (Recommended)

1. Copy the template:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and set your token:
   ```bash
   nano .env  # or use any text editor
   ```
   
   Change this line:
   ```env
   BOT_TOKEN=PUT_TOKEN_HERE
   ```
   
   To your actual token:
   ```env
   BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
   ```

3. Save and run:
   ```bash
   python3 bot.py
   ```

### Option 3: Auto Setup Script

```bash
chmod +x setup.sh
./setup.sh
```

The script will:
- Create `.env` from template
- Prompt you for your bot token
- Install dependencies
- Offer to start the bot

---

## Getting a Bot Token

If you don't have a token yet:

1. Open Telegram
2. Message [@BotFather](https://t.me/BotFather)
3. Send: `/newbot`
4. Follow prompts to choose:
   - Bot name (e.g., "My MikroTik Bot")
   - Bot username (e.g., "my_mikrotik_bot" — must end in `bot`)
5. Copy the token BotFather gives you
6. Paste it into `.env` or export it

---

## After Fixing

Once the bot starts successfully, you'll see:

```
2026-02-18 09:35:39 [Monitor] INFO: Monitor started
2026-02-18 09:35:39 [Watchdog] INFO: Watchdog started
2026-02-18 09:35:39 [MikroBot] INFO: Bot is running. Press Ctrl+C to stop.
2026-02-18 09:35:39 [aiogram.dispatcher] INFO: Start polling
```

**No more "Polling stopped" or "Unauthorized" errors!**

Then:

1. Open Telegram
2. Search for your bot (@your_bot_username)
3. Send `/start`
4. You'll become the owner (first user)
5. Use `/add_router` to connect your MikroTik

---

## Getting Your Telegram User ID (Optional)

The `OWNER_ID` in `.env` is optional. If you want to set it:

1. Forward any message to [@userinfobot](https://t.me/userinfobot)
2. It will reply with your user ID (a number like `123456789`)
3. Add to `.env`:
   ```env
   OWNER_ID=123456789
   ```

If you skip this, **the first person to /start your bot becomes owner automatically**.

---

## Verification Checklist

✅ You have a bot token from @BotFather  
✅ Token is in `.env` file OR exported as environment variable  
✅ `.env` is in the same directory as `bot.py`  
✅ No quotes around the token in terminal exports  
✅ Token format: `NUMBERS:LETTERS` (example: `123456789:ABCdefGHI`)  

---

## Still Having Issues?

**Check the logs:**

```bash
python3 bot.py
```

Look for the first error message. Common issues:

1. **"No such file or directory: '.env'"**
   → Create `.env` from `.env.example`

2. **"ModuleNotFoundError: No module named 'aiogram'"**
   → Run: `pip3 install -r requirements.txt`

3. **"Unauthorized" still appearing**
   → Your token is wrong. Re-copy from @BotFather

4. **"Cannot connect to router"** (different error, after bot starts)
   → This is normal — you haven't added a router yet
   → Use `/add_router` in Telegram after bot starts

---

## Next Steps (After Bot Starts)

See `SETUP.md` for:
- Adding your first router
- Understanding RBAC roles
- Feature documentation
- Troubleshooting

See `FEATURES.md` for:
- Complete list of 150+ implemented features
- API coverage details
- UI screenshots (text-based)

---

**TL;DR: Get token from @BotFather → Put in .env → Run bot.py → Success! 🎉**
